package com.csi.oops;

public class TypeCastBasics {
	public static void main(String[] args) {

		int productPrice=5656;
		
		double pPrice = productPrice;//UpCasting
		
		System.out.println("\n Product Price: "+ pPrice);
		
		double empSalary=89898.99;
		
		//int employeeSalary = empSalary;//Downcasting
		int employeeSalary = (int) empSalary;
		
		System.out.println("\n Employee Salary: "+ employeeSalary);
		
	}
}
