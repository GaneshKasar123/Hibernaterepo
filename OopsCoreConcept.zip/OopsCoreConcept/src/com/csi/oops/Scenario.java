package com.csi.oops;

class Customer
{
	int custId=121;
	void get(String custName)
	{
		System.out.println("Cust Name: "+ custName);
	}
}

class Brand extends Customer
{
	void set(String brandName)
	{
		System.out.println("Brand Name: "+ brandName+""+ super.custId);
	}
}
class Shop extends Customer
{
	void net(String sName)
	{
		System.out.println("Shp Name: "+sName+""+super.custId);
	}
}
public class Scenario {
	public static void main(String[] args) {

		Shop s1 = new Shop();
		s1.get("BINU");
		s1.net("WW");
		
		
	}
}
