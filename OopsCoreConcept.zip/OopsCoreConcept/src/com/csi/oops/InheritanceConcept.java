package com.csi.oops;

class Department {

	int deptCode = 999;

	void get(int deptId, String deptName) {
		System.out.println("\n Department Id: " + deptId + "\n Department Name: " + deptName);
	}

	void set() {
		System.out.println("I am from set");
	}
}

class Employee extends Department {

	int deptCode = 555;
	void net(int empId, String empName, double empSalary) {
		System.out.println(
				"\n Employee Id: " + empId + "\n Employee Name: " + empName + "\n Employee Salary: " + empSalary);
	}

	void show(String empAddress) {
		System.out.println("\n Employee Address: " + empAddress+"\n Department Code: "+ super.deptCode);
	super.set();
	}
}

class Product extends Employee
{
	void display(int productId, String productName)
	{
		System.out.println("\n Product Id: "+productId+"\n Product Name: "+productName);
	}
}

class Company extends Product{
	void pop(String companyName, String companyAddress)
	{
		System.out.println("\n Company Name: "+companyName+"\n Company Address: "+companyAddress);
	}
}



public class InheritanceConcept {

	public static void main(String[] args) {

		/*Employee e1 = new Employee();
		e1.get(101, "HR");
		
		e1.net(121, "BINU", 23435.78);
		e1.show("PUNE");*/
		
		/*Employee e1 = (Employee) new Department();
		e1.get(101, "HR");
		
		e1.net(121, "BINU", 23435.78);
		e1.show("PUNE");*/
		
		/*Department dd = new Employee();
		dd.get(101, "HR");
		
		((Employee) dd).net(121, "BINU", 23435.78);
		((Employee) dd).show("PUNE");*/
		
		
		/*Product pp = new Product();
		
		pp.get(101, "HR");
		
		pp.net(121, "BINU", 23435.78);
		pp.show("PUNE");
		pp.display(111, "MI SMART TV");*/
		
		Company cc = new Company();
		cc.get(101, "HR");
		
		cc.net(121, "BINU", 23435.78);
		cc.show("PUNE");
		cc.display(111, "MI SMART TV");
		cc.pop("CSI", "INSPIRIA MALL | PUNE | MH | INDIA");
		
	}
}
